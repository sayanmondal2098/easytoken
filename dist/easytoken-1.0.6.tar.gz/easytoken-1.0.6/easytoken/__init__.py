
from easytoken.easytoken import Wordeasytoken
from easytoken.easytoken import Sentenceeasytoken